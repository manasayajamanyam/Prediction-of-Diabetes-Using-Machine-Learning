from django.db import models

# Create your models here.

class BipolarData(models.Model):
    Age=models.IntegerField()
    Right_answers=models.IntegerField()
    Audio_prosody=models.IntegerField()
    Combined_channel=models.IntegerField()
    Face_video=models.IntegerField()
    Body_video=models.IntegerField()
    Positive_valence=models.IntegerField()
    Negative_valence=models.IntegerField()
    Dominant=models.IntegerField()
    Submissive=models.IntegerField()


class WebsiteUser(models.Model):
    first_name=models.CharField(max_length=45)
    last_name=models.CharField(max_length=45)
    email=models.EmailField(max_length=67)
    password=models.CharField(max_length=67)
    username=models.CharField(max_length=89)

